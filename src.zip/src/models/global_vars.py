
class global_vars:
    base_MVA = 100
    enforce_Qlim = False